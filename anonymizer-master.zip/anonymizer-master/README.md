# anonymizer
Anonymize workerids when using [cosub](https://github.com/longouyang/cosub). 

Assumes that workerids are in `./production-results`.

Run by typing `python ./anonymize-workerids.py foo` where foo is the path of your project repository, e.g. `~/username/project_repo`. 


